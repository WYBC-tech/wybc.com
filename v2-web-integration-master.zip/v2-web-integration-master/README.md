# spinitron.github.io/v2-web-integration/

A website using static HTML documents and CSS stylesheets to demonstrate the use of iframe
website integration with Spinitron V2.

This is live demo. Go to

* [spinitron.github.io/v2-web-integration/](http://spinitron.github.io/v2-web-integration/)

to view the pages.

You could, for example, fork this repository and tinker with it to see how it works using Github as web host, just as we do.
